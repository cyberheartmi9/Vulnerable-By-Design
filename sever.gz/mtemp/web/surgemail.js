# Various javascript functions used throughout SurgeMail

function ImageO(e)
{
	if (!e) var e=window.event;
	var S=e.srcElement;
	if (!S) S=e.target;
	S.OldSrc=S.src;
	var x=S.src;
	var x2=x;
# Change src from something like /web/fcg/test.gif to /web/fcg/testH.gif
	var l=x.length;
	while(l>0 && x.charAt(l-1)!='.') 
		l--;
	if (l>0) {
		x2=x.substring(0,l-1)+"H"+x.substring(l-1);
	}
	S.src=x2;
}
function ImageU(e)
{
	if (!e) var e=window.event;
	var S=e.srcElement;
	if (!S) S=e.target;
	S.src=S.OldSrc;
}
function MO(e)
{
	//alert("a1");
	if (!e) var e=window.event;
	var S=e.srcElement;
	if (!S) S=e.target;
	if (!S) return;
	S.OldClassName=S.className;
	S.className="spbuttonh";
}

function MU(e)
{
	if (!e) var e=window.event;
	var S=e.srcElement;
	if (!S) S=e.target;
	if (!S) return;
	S.className=S.OldClassName
}


function MC(e)
{
	//if (!e) var e=window.event;
	//var S=e.srcElement;
	//if (!S) S=e.target;
	//S.OldClassName="spbuttony"
	//S.className="spbuttony"
}


function MC2(e,msg)
{
	if (!e) var e=window.event;
	var S=e.srcElement;
	if (!S) S=e.target;
	if (!S) return MC(e);
	var text=S.confirm_message;
	if (!text) text=msg;
	if (!text) text="$$Are you sure you want to$$ '"+S.value+"'?";
	if (!confirm(text)) return false;
	MC(e);
	return true;
}

function MC3(e)
{
	if (!e) var e=window.event;
	var S=e.srcElement;
	if (!S) S=e.target;
	if (!S) return MC(e);
	S = S.parentElement;
	S.click();
	MC(e);
	stopEvent(e)
}
function stopEvent(e) {
	if(!e) alert('invalid stopEvent call');
	
	//e.cancelBubble is supported by IE - this will kill the bubbling process.
	e.cancelBubble = true;
	e.returnValue = false;

	//e.stopPropagation works only in Firefox.
	if (e.stopPropagation) {
		e.stopPropagation();
		e.preventDefault();
	}
}

function add_field(text,field,cb,addstr) {
	var a = text.value;
	var b = field.value;
	var i = 0;
	var c,d;

	a = a.toLowerCase();
	p = a.split(",");
	a = "";
	
	for(i = 0; i < p.length; i++) {
		for(j = 0; j < field.options.length; j++) {
			if (p[i].indexOf(addstr) == 0) c = p[i].slice(addstr.length);
			else c = p[i];

			if (field.options[j].value) d = field.options[j].value;
			else d = field.options[j].text;
			
			d = d.toLowerCase();
			
			if (c == d) {
				if (a.length) a += ",";
				a += p[i];
				break;
			}
		}
	}

	b = b.toLowerCase();
	for(i = a.indexOf(b); i != -1; i = a.indexOf(b,i+1)) {
		c = a.slice(i,i+b.length);
		if (b == c &&
		   (a.length == i+b.length ||
		    a.charAt(i+b.length) == ' ' ||
		    a.charAt(i+b.length) == ',')) return ;
	}

	if (a.length) a += ",";
	if (cb && cb.checked) a += addstr;
	a += field.value;
	
	text.value = a;
}
function set_and_focus(field,value) {
	field.value = value;
	field.focus();
}
function fsubmit_lcmd(cmd,lcmd) {
	document.main.lcmd.value = lcmd;
	fsubmit(cmd);
	document.main.lcmd.value = "";
}
function fsubmit_nolcmd(cmd) {
	var old_lcmd;
	

	if (document.main.lcmd) {
		old_lcmd = document.main.lcmd.value;
		document.main.lcmd.value = "";
	}
	fsubmit(cmd);
	if (document.main.lcmd)
		document.main.lcmd.value = old_lcmd;
}
function fsubmit(cmd) {
	document.main.cmd.value = cmd;
	document.main.submit();
	document.main.cmd.value = "";
}
function are_you_sure() {
	return confirm("$$Are you sure?$$");
}
function sort_type(type) {
	var s = document.createElement("INPUT");
	s.setAttribute("type","hidden");
	s.setAttribute("name","cmd");
	s.setAttribute("value","search_sort");
	document.main.appendChild(s);
	document.main.search_sort.value = type;
	document.main.submit();
}
function sel_all(prefix) {
	var i,v = -1;
	for(i = 0; i < document.main.length; i++) {
		if (document.main.elements[i].type != "checkbox") continue;
		if (document.main.elements[i].name.indexOf(prefix) != 0) continue;
		if (document.main.elements[i].name.substr(prefix.length) == "all") continue;
		if (v == -1) v = !document.main.elements[i].checked;
		document.main.elements[i].checked = v;
	}
}
function get_obj(name)
{
	if (document.getElementById) 
		return document.getElementById(name)
}
function set_visible(name,vis)
{
	if (document.getElementById) {
		obj=document.getElementById(name);
		if (obj && vis) obj.style.visibility="visible";
		if (obj && !vis) obj.style.visibility="hidden";
	}
}
function show_obj(name,vis)
{
	if (document.getElementById) {
		obj=document.getElementById(name);
		if (obj && vis==1) obj.style.display="inline";
		if (obj && vis==0) obj.style.display="none";
	}
}
function domain_list_selection(list,field,cmd,surgewall)
{
	if (document.main.username != undefined) {
		var at = document.main.username.value.indexOf("@");
		if (at != -1) document.main.username.value = document.main.username.value.substring(0,at);
	}
	
	v = list.options[list.selectedIndex].value;
	if (v == "-1_") set_and_focus(field,'');
	else {
		i = v.indexOf("_");
		if (i != -1 && v.substr(i+1) != surgewall) {
			document.main.cmd.value = cmd;
			document.main.submit();
		}
	}
}
function domain_list_selection2(list,field,cmd,surgewall)
{
	if (document.main.username != undefined) {
		var at = document.main.username.value.indexOf("@");
		if (at != -1) document.main.username.value = document.main.username.value.substring(0,at);
	}
	
			document.main.cmd.value = cmd;
			document.main.submit();
}

function lib_name_only(name)
{
	ret=name;
	//alert(name);
	for(i=0;i<name.length;i++) {
		if (name.charAt(i)=='/') {
			ret=name.substr(i+1);
		}
	}
	return ret;
}

function sort(value) {
	if (document.main.search_sort.value == value) {
		if (document.main.search_reverse.value == "true")
			document.main.search_reverse.value = "false";
		else
			document.main.search_reverse.value = "true";				
	}
	else {
		document.main.search_sort.value = value;
		document.main.search_reverse.value = "false";
	}	
	document.main.submit();
}

function update_ccexpires(type,list) {
	var v = list.options[list.selectedIndex].text;
	var f = document.main;
	var t = f.ccexpires.value;

	if (t.length==0) t = "01/15";
	if (t.indexOf("/")<0) t = t + "/15";
	if (type == "m") {
		t = v + t.substr(t.indexOf("/"));
	}
	else if (type == "y") {
		t = t.substr(0,t.indexOf("/")) + "/" + v;
	}
	f.ccexpires.value = t;
}

function init_ccexpires(value,type,list) {
	var t;
	var i;
	
	if (list == undefined) return ;
	
	if (type == "m") {
		t = value.substr(0,value.indexOf("/"));
	}
	else if (type == "y") {
		t = value.substr(value.indexOf("/")+1);
	}

	for(i = 0; i < list.options.length; i++) {
		if (list.options[i].text == t) {
			list.options.selectedIndex = i;
			break;
		}
	}
}

function upgrade_bank_group(list,frm) {
	if (list.options[list.options.selectedIndex].id == "0") {
		frm.cctype.disabled = true;
		frm.ccname.disabled = true;
		frm.ccnumber.disabled = true;
		frm.ccciv.disabled = true;
		frm.ccexpires_month.disabled = true;
		frm.ccexpires_year.disabled = true;
	}
	else {
		frm.cctype.disabled = false;
		frm.ccname.disabled = false;
		frm.ccnumber.disabled = false;
		frm.ccciv.disabled = false;
		frm.ccexpires_month.disabled = false;
		frm.ccexpires_year.disabled = false;
	}	
}

function initTables(iswebmail)
{
	var tables,subset,i,j;

	if (iswebmail == 'true') return ;
	if (!document.all) return;
	
	tables = document.getElementsByTagName('table');
	for (i=0;i<tables.length;i++) {
		if (!tables[i].attributes['class'] || tables[i].attributes['class'].value != 'visible') continue;
		
		subset = tables[i].getElementsByTagName('th');
		for (j=0;j<subset.length;j++) 
			if (subset[j].parentElement.parentElement.parentElement == tables[i])
				subset[j].style.cssText = subset[j].style.cssText + "background-color: #D6D6CE; border-bottom: 1px solid #778899; border-left: 1px dotted #778899; padding: 2px;";		    	
		
		subset = tables[i].getElementsByTagName('td');
		for (j=0;j<subset.length;j++)
			if (subset[j].parentElement.parentElement.parentElement == tables[i])
				subset[j].style.cssText = subset[j].style.cssText + "border: 1px dotted #2f4f4f;padding: 3px;";
	}
}

function initPage()
{
	if (document.location.href.indexOf('setting_search=true')>0){
		var name="none";
		search_term = document.location.href.substr(document.location.href.indexOf('#')+1);
		var elem = document.getElementsByTagName('a');
		for(i = 0; i < elem.length; i++) {
			var name=elem[i].getAttribute("name");
			if(name==search_term) {
				name = search_term;
				var p=elem[i];
				break;
			}
		}
		
		if (name=="none") return;
		
		while ((p.nodeName!='TR' && p.nodeName!='DIV') && p.parentNode)
			p=p.parentNode;

		if (p.nodeName!='TR' && p.nodeName!='DIV' ) return;
		
		p.className = p.className + " search_setting";
	}
}

function dge(id)
{
	return document.getElementById(id);
}

var CLASSNAME = "className";

function class_remove(o,name){
	o[CLASSNAME] = o[CLASSNAME].replace(' '+name,'').replace(name,'');
}
function class_add(o,name){
    var val = o[CLASSNAME];
	if (val.indexOf(name) == -1) 
		o[CLASSNAME] += (val?' ':'')+name;
}
function class_contains(o,name){
    return (o[CLASSNAME].indexOf(name) != -1);
}
function class_set(o,name){
    o[CLASSNAME]=name;
}
