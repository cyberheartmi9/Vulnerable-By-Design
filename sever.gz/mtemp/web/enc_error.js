	alert('||message|| ||info|| ||warning||');
	status_set('An error: ||message|| ||info|| ||warning||');
