# This page displays the user's address book for surgeweb until surgeweb has full addressbook support

// This is ** surgeplus_surgeweb_abk.js ** Temporary addressbook autocompletion (do not remove this line)

||begin_list||
#	abk_entry("marijn","Marijn (netwin)","marijn@netwin.co.nz","shortlist_na","1","1");
#	abk_entry("||encode_quotes||name||","||encode_quotes||abk_full_name||","||encode_quotes||abk_email||","shortlist_na","||abk_instant||","||abk_nused||");
  ||ifdef||is_any_contacts||
  ||ifdef||is_pre_list_callback||
  ||elseifdef||is_post_list_callback||
  ||else||
  	abk_entry('||string_encode(contact_nickname)||', '||string_encode(contact_full_name)||', '||string_encode(contact_email)||','shortlist_na','','');
  ||endif||
  ||endif||
||end_list||

