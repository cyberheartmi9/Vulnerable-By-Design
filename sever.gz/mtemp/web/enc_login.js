	var el = document.getElementById('pdiv'); 
	el.className = "visiblediv";

	status_set('showing login stuff enc_login.js');
