	var el = document.getElementById('pdiv'); 
	el.className = "hiddendiv";
	el = document.getElementById('cdiv'); 
	el.className = "hiddendiv";
	el = document.getElementById('test'); 
	el.key.value = '||show_key||';
	status_set('enc_key Script returned the key ok ||show_key||');
	page_decrypt();
	status_set('Message body has been decrypted');
