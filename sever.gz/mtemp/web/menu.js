// *** Generic menu related stuff ***
// This menu implementation is a bit verbose and incomplete, needs more work
var global_active_menu;
function do_menu_show(id,e,own_calc,fn,posn)
{
	mnu=document.getElementById(id);
	if(fn) mnu.cb=fn;
	
	var t=target(e);
	
	if (t.tagName.toLowerCase()=='img') 
		t=t.parentNode;

	if (menu_timer)	clearTimeout(menu_timer);
	if (global_active_menu && mnu!=global_active_menu)
		menu_hide2(global_active_menu);
	if(posn && posn['cursor'])
		menu_position_cursor(e,mnu,posn);
	else
		menu_position(t,mnu,posn);

	class_remove(mnu,'hidden');
	global_active_menu=mnu;
	return stopEvent(e);
}
function do_menu_show2(mnu,el,posn)
{
	if (menu_timer)	clearTimeout(menu_timer);
	if (global_active_menu && mnu!=global_active_menu)
		menu_hide2(global_active_menu);
	menu_position(el,mnu,posn,sw.active.field_eframe);

	class_remove(mnu,'hidden');
	global_active_menu=mnu;
}

function menu_position_old(ctl,mnu,posn)
{
	if(true){
		var x=0;
		for(var p=ctl;p.offsetParent;p=p.offsetParent){
			x+=p.offsetLeft;
		}
		if(posn&&posn.xoffset) x+=posn.xoffset;
		if(posn&&posn.right)
			mnu.style.left=px(x+ctl.offsetWidth-mnu.offsetWidth);
		else
			mnu.style.left=px(x);
	}else{
		mnu.style.left=px(ctl.offsetLeft);
	}
	if(true){
		var x=0;
		for(var p=ctl;p.offsetParent;p=p.offsetParent){
			x+=p.offsetTop;
		}
		if(posn&&posn.yoffset) x-=posn.yoffset;
		if(posn&&posn.upwards)
			mnu.style.top=px(x-mnu.offsetHeight);
		else
			mnu.style.top=px(x+ctl.offsetHeight-2);
	}else{
		mnu.style.top=ctl.offsetTop+ctl.offsetHeight+'px';	
	}
}

function menu_position(ctl,mnu,opt,ctl2)
{
	var pos = posn_offset(ctl);
	if(ctl2) pos = posn_offset(ctl2,pos);

	if(!opt) opt={};
	if(opt.xoffset) pos[0]+=opt.xoffset;
	if(opt.right) pos[0]+=ctl.offsetWidth-mnu.offsetWidth;

	if(opt.yoffset) pos[1]-=opt.yoffset;
	if(opt.upwards)
		pos[1]-=mnu.offsetHeight;
	else
		pos[1]+=ctl.offsetHeight-2;	
	position_node(mnu,pos);
}
function menu_position_cursor(e,mnu,opt)
{
	var pos = [mouseX(e),mouseY(e)]
	position_node(mnu,pos);
}
function posn_offset(ctl,pos)
{
	if (!pos) pos=[0,0];
	for(var p=ctl;p.offsetParent;p=p.offsetParent) pos[0]+=p.offsetLeft;
	for(var p=ctl;p.offsetParent;p=p.offsetParent) pos[1]+=p.offsetTop;
	return pos;
}
function position_node(mnu,pos)
{
	mnu.style.left=px(pos[0]);
	mnu.style.top=px(pos[1]);
}



var menu_timer;
function x_hide_menu_soon(txt)
{
	if (menu_timer)	clearTimeout(menu_timer);
	menu_timer=setTimeout(function(){
		menu_hide(txt);
	}
	,400);
}
function menu_hide(id)
{
	var o=dge(id);
	if(!o) return;
	class_add(o,'hidden');
	global_active_menu=null;
	if (o.cb)
		o.cb('hide');
}
function menu_hide2(mnu)
{
	if (mnu.cb)
		mnu.cb('hide');
	class_add(mnu,'hidden');
	global_active_menu=null;
}
function menu_delete(id)
{
	if (menu_timer)	clearTimeout(menu_timer);
	var o=dge(id);
	remove_node(o);
	global_active_menu=null;
	if (o.cb)
		o.cb('hide');
}


function menu_action_mouseout(e,txt){
	if (!e) e = window.event;
	var t = target(e);
//	if(pref['sticky_menus']) return;
	x_hide_menu_soon(txt);
}
function menu_action_mouseover(e,txt){
	if (!e) e = window.event;
	var t = target(e);
	if (menu_timer)	clearTimeout(menu_timer);
}
