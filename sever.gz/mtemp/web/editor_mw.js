var xdoc;
var xwin;
function toggleMode(e,outer)
{

	if(!e) e=window.event;
	if(!outer){
		outer=target(e);
		while(!outer.eframe) outer=outer.parentNode;
	}
	xwin=outer.eframe.contentWindow;
	xdoc=xwin.document;
	
 // change the display styles
  if(outer.eframe.viewMode == 2){
    xdoc.body.style.fontFamily = '';
    xdoc.body.style.fontSize = '';
    xdoc.body.style.color = '';
    xdoc.body.style.fontWeight = '';
    xdoc.body.style.backgroundColor = '';
  }else{
    xdoc.body.style.fontFamily = 'monospace';
    xdoc.body.style.fontSize = '10pt';
    xdoc.body.style.color = '#000';
    xdoc.body.style.backgroundColor = '#fff';
    xdoc.body.style.fontWeight = 'normal';
  }

 // do the content swapping
  if(isMSIE()){
    _toggle_mode_ie(outer);
  }else{
    _toggle_mode_gecko(outer);
  }
}

/**
* WYSIWYG_Editor::_toggle_mode_ie
*
* Toggles between design view and source view in the IFRAME element for MSIE
**/
function _toggle_mode_ie(outer){
  if(outer.eframe.viewMode == 2){
    xdoc.body.innerHTML = xdoc.body.innerText;
    xwin.focus();
    outer.eframe.viewMode = 1; // WYSIWYG
	outer.field_switch.value="edit markup";
  }else{
    xdoc.body.innerText = xdoc.body.innerHTML;
    xwin.focus();
    outer.eframe.viewMode = 2; // Code
	outer.field_switch.value="edit html";
  }
}

/**
* WYSIWYG_Editor::_toggle_mode_gecko
*
* Toggles between design view and source view in the IFRAME element for Gecko browsers
**/
function _toggle_mode_gecko(outer)
{
  if(outer.eframe.viewMode == 2){
    var html = xdoc.body.ownerDocument.createRange();
    html.selectNodeContents(xdoc.body);
    xdoc.body.innerHTML = html.toString();
    xwin.focus();
    outer.eframe.viewMode = 1; // WYSIWYG
	outer.field_switch.value="edit html";
}else{
    var html = document.createTextNode(xdoc.body.innerHTML);
    xdoc.body.innerHTML = '';
    xdoc.body.appendChild(html);
    xwin.focus();
    outer.eframe.viewMode = 2; // Code
	outer.field_switch.value="edit markup";
  }
}


function isMSIE()
{
  if(typeof(document.all)=='object'){
    return true;
  }else{
    return false;
  }
}

function init_editor(id)
{
//	eid = document.getElementById(id);
	eid = document.getElementById(id);	
	ew = eid.contentWindow;
	ew.document.designMode = "On";
	return ew;
}

function ed_mousedown(e)
{
	t=target(e);
	if(t.getAttribute('menu')=='true'){
		var outer=t;
		while(!outer.eframe) outer=outer.parentNode;
		var m=ed_show_menu(t.className);
		m.eframe=outer.eframe;
		do_menu_show('ed_menu_'+t.className,e,true);
		dge('ed_menu_'+t.className)._hide_sel=t;
	}
  	return stopEvent(e);
}

function ed_show_menu(id){
	var o=dge('ed_menu_'+id);
	if (!o){
		var o=document.createElement("div");
		o.className = 'xmenu';
		o.id = 'ed_menu_'+id;
		if (id=='fontname'){
			o.innerHTML='<a href="#" class="fontname" param="arial,san-serif">Arial</a>'+
						'<a href="#" class="fontname" param="comic sans ms,san-serif">Comic Sans MS</a>'+
						'<a href="#" class="fontname" param="courier new,monospace">Courier New</a>'+
						'<a href="#" class="fontname" param="garamond,serif">Garamond</a>'+
						'<a href="#" class="fontname" param="helvetica,san-serif">Helvetica</a>'+
						'<a href="#" class="fontname" param="tahoma,san-serif">Tahoma</a>'+
						'<a href="#" class="fontname" param="times new roman,serif">Times New Roman</a>'+
						'<a href="#" class="fontname" param="verdana,san-serif">Verdana</a>';

		}else if (id=='fontsize'){
			o.innerHTML='<a href="#" class="fontsize" param="1" >8 pt</a>'+
						'<a href="#" class="fontsize" param="2">10 pt</a>'+
						'<a href="#" class="fontsize" param="3">12 pt</a>'+
						'<a href="#" class="fontsize" param="4">14 pt</a>'+
						'<a href="#" class="fontsize" param="5">16 pt</a>'+
						'<a href="#" class="fontsize" param="6">24 pt</a>'+
						'<a href="#" class="fontsize" param="7">30 pt</a>';
		}else if (id=='forecolor' || id=='backcolor'){
			o.innerHTML='<table onmouseup="ed_color_select(event,\''+id+'\')">'+ed_color_swatches(5,'labels')+'</table>';
		}else{
			o.innerHTML="boohoo..."
		}
		o.onmouseup=ed_click;
		o.onmouseout=function(e){if(!e) e=window.event; menu_action_mouseout(e,o.id)}; 
		o.onmouseover=function(e){if(!e) e=window.event; menu_action_mouseover(event,o.id)};

		document.body.appendChild(o);
	}
	return o;
}

var label_cols= [
	["#F1F5EC","#B2D1C1",""],["#FFE3E3","#F0B2B2",""],["#F3E7B3","#C4AD4C",""],["#D3E2C3","#98BB74",""],["#C0D6FF","#6B9EFF",""],
	["#E8EDF6","#CDD2DA",""],["#FDE9F4","#DACACF",""],["#FFF0E1","#F9D4B2",""],["#FFFFD4","#D0D0C0",""],["#DFE2FF","#B2B2F0",""],
	["#D7C8FA","#D7C8FA",""],["#F0A3A3","#F0A3A3",""],["#F2C98F","#F2C98F",""],["#A9CC87","#A9CC87",""],["#8CB4FF","#8CB4FF",""]];

function ed_colors(){
 	return label_cols.concat([
		["purple","#999",""],["red","#999",""],["yellow","#999",""],["green","#999",""],["blue","#999",""],
		["white","#999",""],["#aaa","#999",""],["#777","#999",""],["#444","#999",""],["black","#999",""]]);
}
function ed_color_select(e,id)
{
	var cols=ed_colors();
	var el=target(e);
	var picked=el.getAttribute('pickid');
	if(!picked) return;
	ed_click2(e,id,cols[picked][0]);
}
function ed_color_swatches(per_line)
{
	var cols=ed_colors();
	var txt='';
	for(var i=0;i<cols.length;i++){
  		if( i%per_line == 0 )txt += '<tr>'; 	
		txt+='<td class="swatch_hover"><div class="swatch" style="background:'+cols[i][0]+';border:1px solid '+cols[i][1]+';" pickid="'+i+'"></div>';
	}
	return txt;
}


// *** Actually execute command in the html editor ***
function editor_do(cmd,param)
{
	xwin=(sw.active ? sw.active.field_eframe.contentWindow : document.getElementById('eframe1').contentWindow);
  	xwin.document.execCommand(cmd,false, param);
  	xwin.focus();
  	return false;
}

// Editor toolbar click handling events which never get outside these DOM elements
// generic handler for all single action html editor items
function ed_click(e,param,t)
{
	if(!e) e=window.event;
	t=target(e);
	var outer=t;
	while(!outer.eframe) outer=outer.parentNode;
	xwin=outer.eframe.contentWindow;
	xwin.focus();
	if (t.tagName.toLowerCase()=="a" && t.getAttribute('menu')!='true'){
		if(t.className=='createlink'){
			if(isMSIE()){
				xwin.document.execCommand('createlink',false, undefined);
			}else{
				var link_fn=function(val){
					if (!val) return;
					xwin.focus();
					xwin.document.execCommand('createlink',false, val);
				};
				if(window.x_prompt){
					x_prompt("Url to insert as link :","",link_fn);
				}else{
					var x=prompt("Url to insert as link :");
					link_fn(x);
				}
			}
		}else{
			var param=t.getAttribute('param');
			if(param==null) param=undefined;
			xwin.document.execCommand(t.className,false, param);
		}
		if (t.parentNode._hide_sel) class_remove(t.parentNode._hide_sel,'hoverjs');
	}
  	stopEvent(e);
}
function ed_click2(e,cmd,param,xwin)
{
	if(!e) e=window.event;
	t=target(e);
	var outer=t;
	while(!outer.eframe) outer=outer.parentNode;
	xwin=outer.eframe.contentWindow;
	xwin.focus();
	xwin.document.execCommand(cmd,false, param);
}
// Anything that needs more specialised action for some reason
function ed_click_ex(e,cmd,param)
{
	xwin=(sw.active ? sw.active.field_eframe.contentWindow : document.getElementById('eframe1').contentWindow);
  	xwin.focus();
  	xwin.document.execCommand(cmd,false, param);
  	return stopEvent(e);
}

function ed_content(id)
{
	var el=dge(id);
	if (!el) return '';
	
	if (el.viewMode==2)
		toggleMode(undefined,dge('etbar'))
	
	return el.contentWindow.document.body.innerHTML;
}
function ed_init(value,etbar,eframe)
{
	if(!etbar) etbar='etbar';
	if(!eframe) eframe='eframe';
	
	var tb=dge(etbar);
	tb.eframe=dge(eframe);
	tb.field_switch=dge('editor_switch_button');
	setTimeout(function(){
		var xwin = init_editor(eframe);
		var xdoc=xwin.document;
		xdoc.open();
//		xdoc.write('<html><head>');
//		xdoc.write('<style>');
//		xdoc.write(' P{margin:0px;padding:0px;}');
//		xdoc.write(' {FONT-SIZE: 11pt;FONT-FAMILY:Arial,Helvetica,sans-serif;background:white;}');
//		xdoc.write('</style>');
//		xdoc.write('<body>'+value+'</body></html>')

		xdoc.write(value);
		xdoc.close();

	},5);
}

