	status_set('Asking sender to reset password, wait for another email');
