/* Initialisation code for netwin's use of the usableforms javascript form code */

window.onload = initialize; 
/* Why no window.onload = function () {} ? Because NN3 doesn't support the function
	constructor and gives an error message. This site must be accessible to NN3 */
function initialize () {
	if (self.init) self.init();
}

window.onunload = remove;
function remove () {
	if (self.exit) self.exit();
}

