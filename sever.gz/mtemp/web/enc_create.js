	var el = document.getElementById('cdiv'); 
	el.className = "visiblediv";
	status_set('Prompting user to create password');
