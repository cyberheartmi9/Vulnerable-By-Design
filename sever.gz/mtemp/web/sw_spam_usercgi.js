// mapping of settings...
var map_sw_2_core, map_core_2_sw, map_ctls_to_ctl0, ctl0_mapping, ctl_text, ctl2_allow, extra_info;

||include||sw_spam_convert_include.js||

// Ok we have received a javascript object of all the exisitng settings. Now do any required mappings of these :-)
try{
	dbg=top.dbg;
}catch(ex){
	dbg=function(){}
}
var working_values;

# ***
# Various logical entry points
# ***

# Init
function spam_onload(){
	spam_onload_real();
}

# Set summary ctls from interface
function set_ctl0(e,ctl){
	set_ctl0_real(e,ctl)
}
function set_ctl1(e,ctl){
	set_ctls(e,ctl.value,undefined);
}
function set_ctl2(e,ctl){
	set_ctls(e,undefined,ctl.value);
}


# *** Implementation ***


# Page loaded
function spam_onload_real()
{
#	alert("spam page loaded - boohoo");
	working_values=cloneObject(original_values);	
	var state=map_core_2_sw(working_values);
	if (page=='sw_spam.htm'){
		sw_ctls_just_set(state);
		simple_friend_init(working_values);
	}else if (page=='sw_unknown1.htm'){
		simple_friend2_init(working_values);
		debug_info();
	}
}


# Save, before form submit
function spam_save_clicked(ctl)
{
	simple_friend_prepost(working_values);
}

# One of the three top level surgeweb spam controls changed
function sw_spam_change(e,ctl)
{
	show_extra_info(ctl);

	switch(ctl.name){
	case 'spam_onestep':
		break;
	case 'spam_handling_certain':
		break;
	case 'spam_handling_likely':
		break;
	}
}

# One real spam / user.cgi controls has changed
function sw_core_change(e,ctl)
{
#	debugger;
	var tag=ctl.tagName.toLowerCase();
	var type=ctl.type;
#	alert('** tag='+tag+' type='+type)

	if(tag=='select'){
		working_values[ctl.id]=ctl.value;
	}else if (tag=='input' && type=='radio'){
		if(ctl.id=='friend_mode_simple')
			simple_friend_change(ctl);		
		else
			working_values[ctl.id]=ctl.value;
	}else{
		alert('invalid state')
		return
	}
#		working_values[ctl.name]=ctl.value;

	//recalculate top controls
	var state=map_core_2_sw(working_values);
	sw_ctls_just_set(state);
}

function sw_core_change2(e,ctl)
{
	var tag=ctl.tagName.toLowerCase();
	var type=ctl.type;

	if (tag=='input' && type=='radio'){
		if(ctl.id=='friend_mode_simple')
			simple_friend2_change(ctl);		
	}

	debug_info();
}



function sw_ctls_just_set(state)
{
	var ctl1=dge('spam_handling_certain')
	var ctl2=dge('spam_handling_likely')

	ctl_enable_allowed(ctl1);
	ctl1.value=state[0];
	show_extra_info(ctl1);

	ctl_enable_allowed(ctl2,ctl2_allow[state[0]]);
	ctl2.value=state[1];		
	show_extra_info(ctl2);

	// Check whether that actually succeeded??
	
	ctl0_just_set(state);
	
	debug_info();
}

function ctl_enable_allowed(ctl,allowed)
{
	var i,o,j,first_allow;
#	var try_for_done=false;

	for(i=ctl.options.length-1;i>=0;i--) ctl.remove(i);		

	var x=ctl_text[ctl.id];	
	for (i in x) {
		o=new Option(x[i],i);
		if(allowed){
			o.disabled=true;
			for(j=allowed.length-1;j>=0;j--){
				if(allowed[j]==i){
					if(!first_allow)
						first_allow=i;
					o.disabled=false;
#					if(i==try_for){
#						o.selected=true;
#						try_for_done=true;
#					}
					break;
				}
			}
		}
		ctl.options.add(o);
	}
	
	if(isIE7){ 
		// hack it expecially for IE7 which does not support disabled options:-((
		for(i=0;i<ctl.options.length;i++){
			o=ctl.options[i];
			o.style.color = o.disabled?'#CCC':'#000';	
		}
	}
	return first_allow;
}
function ctl2_allowed(val1,val2)
{
	var allowed=ctl2_allow[val1];	
	for(var j=allowed.length-1;j>=0;j--){
		if(allowed[j]==val2) return true;
	}
	return false;
}



function set_ctl0_real(e,ctl)
{
	show_extra_info(ctl);
	var vals=ctl0_mapping[ctl.value];	
	if (!vals) return;
	
	set_ctls(e,vals[0],vals[1]);
}

# Ctl 1 set in interface and applied with prefereed value of ctl2 resulting
function set_ctls(e,val1,val2)
{
	var ctl1=dge('spam_handling_certain');
	if(!val1)val1=ctl1.value;
	
	var ctl2=dge('spam_handling_likely');
#	if(!val2)val2=ctl2.value;	// Ignore this, instead set to most appropriate value
	if(!ctl2_allowed(val1,val2))
		val2=ctl2_allow[val1][0];
		
#	Set the real underlying values based on our controls
	map_sw_2_core(val1,val2,working_values);
	update_ui(working_values);
	
#	Now use the real values to work out our control values	
	var state=map_core_2_sw(working_values);
	sw_ctls_just_set(state);
}

function set_ctl2_real(e,ctl2,plain)
{
	show_extra_info(ctl2);
	var ctl1=dge('spam_handling_likely');
	map_sw_2_core(ctl1.value,ctl2.value,working_values);
	update_ui(working_values);
}

function debug_info()
{
#	extra_info('extra_info1',original_values);
	extra_info('extra_info2',working_values);
}

function show_extra_info(ctl,custom){
	if(ctl.extra_info){
		class_add(ctl.extra_info,'hidden');
	}
	var el=dge('info__'+ctl.name+'__'+(custom?custom:ctl.value));
	if(el){
		ctl.extra_info=el;
		class_remove(el,'hidden');
	}
}


function simple_friend_change(ctl)
{
	dbg('***:'+ctl.value)
	if(ctl.value=='unknown_sender') {
		setTimeout(function(){alert('Please use the unknown sender controls page to configure "unknown sender" actions')})
		simple_friend_init(working_values);
		return;
	}
	working_values['friend_mode']=ctl.value;
}
function simple_friend2_change(ctl)
{
	dbg('***:'+ctl.value)
	if(ctl.value=='none') {
		if(document.usercgi_allow_spam==true){
			alert('Please use the spam controls page to complete or customise configuration - spam handling currently set to optimal silent handling')
			working_values['friend_mode']='silent';
			document.main.friend_smite.value=10;
			document.main.spam_subject.value=5;
		}else{
			working_values['friend_mode']='list';		
		}
		return;
	}
	working_values['friend_mode']=ctl.value;
}
function simple_friend_init(jsval)
{
	if(jsval.friend_mode=='ask' || jsval.friend_mode=='smite' || jsval.friend_mode=='safe')	
		option_set(document.main.friend_mode_simple,'unknown_sender');
	else
		option_set(document.main.friend_mode_simple,jsval.friend_mode);
}
function simple_friend2_init(jsval)
{
	if(jsval.friend_mode=='ask' || jsval.friend_mode=='smite' || jsval.friend_mode=='safe')	
		option_set(document.main.friend_mode_simple,jsval.friend_mode);
	else
		option_set(document.main.friend_mode_simple,'none');
}

function simple_friend_prepost(jsval)
{
	document.main.friend_mode.value=jsval.friend_mode;
}


function option_set(ctl, val) 
{
	for(var i = 0; i < ctl.length; i++) {
		if(ctl[i].value == val)
			ctl[i].checked = true;
	}
}

function enable_friends()
{
	document.main.friend_mode.value='list';
	document.main.recent_out_auto.checked=true;
}
function save_friends()
{
	document.main.cmd.value='cmd_user_friend_save';
	document.main.submit();
}

function ctl0_just_set(state)
{
	return;
	var i,arr;
	ctl=dge('spam_onestep');
	ctl.value=map_ctls_to_ctl0(state);
	
#	Now handle any special cases
	if(state[0]=='mark' && state[1]=='mark')
		show_extra_info(ctl,'little_spam');
	else if(state[0]=='custom' && state[1]=='custom')
		show_extra_info(ctl,'custom');
	else
		show_extra_info(ctl);
}

function update_ui(w)
{
	simple_friend_init(w)
	document.main.friend_smite.value=w.friend_smite;
	document.main.spam_subject.value=w.spam_subject;
	document.main.spam_bounce.value=w.spam_bounce;
	document.main.spam_store.value=w.spam_store;
	document.main.spam_vanish.value=w.spam_vanish;
}

function browser_id()
{
	var UA = navigator.userAgent.toLowerCase();
	if(UA.indexOf('msie 7.0') !=-1) 
		isIE7 = true;
}
var isIE7=false;
browser_id();
