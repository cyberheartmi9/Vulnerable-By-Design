function toggle(e,ctl,id){
	var t = ctl;
	var div = dge(id);
	var v_old,v_new;
	if (class_contains(t,"open")){
		v_old="open";v_new="closed";
	}else{
		v_old="closed";v_new="open";
	}
	class_remove(t,v_old);
	class_add(t,v_new);
	if(v_new=='open')
		class_remove(div,'hidden')
	else
		class_add(div,'hidden');
	
	stopEvent(e);
	
//	top.document.body.scrollTop=0;
//	setTimeout(function(){top.document.body.scrollTop=0},1);
}

// *** Utility functions ***
function target(e){
	var src;
	if(e.target){
		src = e.target;
	}else if(e.srcElement){
		src = e.srcElement;
	}
	if (src.nodeType==3) src = src.parentNode;
	return src;
}
// Find parent of an object
function pe(e){
	return e.parentNode?e.parentNode:e.parentElement;
}
var CLASSNAME = "className";

function class_remove(o,name){
	o[CLASSNAME] = o[CLASSNAME].replace(' '+name,'').replace(name,'');
}
function class_add(o,name){
    var val = o[CLASSNAME];
	if (val.indexOf(name) == -1) 
		o[CLASSNAME] += (val?' ':'')+name;
}
function class_contains(o,name){
    return (o[CLASSNAME].indexOf(name) != -1);
}
function class_set(o,name){
    o[CLASSNAME]=name;
}
function dge(a) { 
	return document.getElementById(a); 
}

function set_show(pg){
	document.menu.show.value=pg;
}
function set_mode(pg){
	document.main.friend_mode.value=pg;
}

function check_login(msg,url){
	var bad=false;
	if(!msg || msg.length==0) return;
//	alert('1'+msg);
	if(msg.indexOf('Login credentials invalid')!=-1) bad=true;
	if(msg.indexOf('ogin failed')!=-1) bad=true;	
	if(msg.indexOf('not found in database')!=-1) bad=true;	
//	alert('1'+msg+'['+bad+']');
	
	if (bad)
		document.location.href=url;
}


function stopEvent(e) {
	if(!e) alert('invalid stopEvent call');
	
	//e.cancelBubble is supported by IE - this will kill the bubbling process.
	e.cancelBubble = true;
	e.returnValue = false;

	//e.stopPropagation works only in Firefox.
	if (e.stopPropagation) {
		e.stopPropagation();
		e.preventDefault();
	}
}

function cloneObject(obj) {
  	var newObj = (obj instanceof Array) ? [] : {};
    for (i in obj) {
        if (typeof obj[i] == 'object') {
            newObj[i] = cloneObject(obj[i]);
        }else{
        	newObj[i] = obj[i];
        }
    }
    return newObj;
}

function px(value){
	if (value<=0) return "1px";
	return value+"px";
}
