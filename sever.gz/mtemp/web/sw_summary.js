document.usercgi_allow_friends=||iftrue(allow_friends)||true||else||false||endif||;
document.usercgi_allow_spam=||iftrue(allow_spam)||true||else||false||endif||;

# Conversion functions, bit horrible actually including these as part of data request
# but improves maintainability as this funcitonality is used by both usercgi pages and surgeweb pages
# and these may be located on separate servers...
||include||sw_spam_convert_include.js||

	usercgi_messages=['||message||','||message2||'];

||if(blank(display_name))||

	usercgi_status={
		'respond':'not available', 
		'fwd_early':'not available', 
		'filter':'not available', 
		'whitelist':'not available', 
#		'spam':'not available', 
		'unknown':'not available', 
		'fwd_late':'not available', 
		'use_late':'false'
	};

||else||

# 	Core user.cgi settings
	usercgi_raw={
		'friend_mode':'||friend_mode||',
		'friend_smite':'||friend_smite||',
		'recent_out_auto':'||recent_out_auto||',
		'spam_subject':'||spam_subject||',
		'spam_body':'||spam_body||',
		'spam_ddpriv':'||spam_ddpriv||',
		'spam_ddfrom':'||spam_ddfrom||',
		'spam_bounce':'||spam_bounce||',
		'spam_store':'||spam_store||',
		'spam_vanish':'||spam_vanish||'
	};

	usercgi_status={
		'respond':
			||iftrue(use_respond)||'<font color="green">$$ENABLED$$</font>'
			||else||'<font style="color:#888">$$INACTIVE$$</font>'||endif||, 
		'fwd_early':
			||if(longer(fwd,(0)))||'<font color="green">$$ENABLED$$</font>'
			||else||'<font style="color:#888">$$INACTIVE$$</font>'||endif||, 
		'filter':
			||begin_list_exceptions||
			||end_list_exceptions||
			||if(greater_than(exception_found,(0))))||'<font color="green">$$ENABLED$$</font>'
			||else|| '<font style="color:#888">$$INACTIVE$$</font>' ||endif||,
#		'whitelist':
#			||if(not(equal(friend_mode,(disabled))))||
#				||if(equal(recent_out_auto,(checked)))||'<font color="green">$$ENABLED$$</font>'
#				||else||'<font color="red" title="$$It is recommended to use the whitelist to prevent false positives in spam detection$$">$$PARTLY DISABLED!$$</font>'||endif||
#			||else||'<font color="red" title="$$It is recommended to use the whitelist to prevent false positives in spam detection$$">$$DISABLED!$$</font>'||endif||, 

#					Actual selection of these done from javascript
#			||if(or(greater_than(spam_store,(0)),greater_than(spam_bounce,(0)),greater_than(spam_vanish,(0)) ))||'<font color="red" title="$$Other settings recommended now for better spam prevention$$">$$ENABLED!$$</font>'
#			||else|| ||if(equal(friend_mode,(smite)))||'<font color="green">$$ENABLED$$</font>'
#			||else|| ||if(or(greater_than(spam_subject,(0)),greater_than(spam_body,(0))))||'<font color="green">$$MARK ONLY$$</font>'
#			||else||'$$DISABLED$$'||endif|| ||endif|| ||endif||, 												

#					Actual selection of these done from javascript
#		'unknown':	  
#			||if(equal(friend_mode,(smite)))||'<font color="green">$$ENABLED$$</font>'
#			||else|| ||if(equal(friend_mode,(ask)))||'<font color="green">$$ENABLED$$</font>'
#			||else|| ||if(equal(friend_mode,(safe)))||'<font color="green">$$KIDSAFE$$</font>'
#			||else||'$$DISABLED$$'||endif|| ||endif|| ||endif||, 					

		'fwd_late':
			||if(longer(fwd,(0)))||'<font color="green">$$ENABLED$$</font>'
			||else||'<font style="color:#888">$$INACTIVE$$</font>'||endif||,

		'use_late':'||use_late||',
		'g_imap_friends':'||g_imap_friends||'
		};
||endif||
		
		usercgi_status['whitelist']={
			'disabled':'<font color="red" title="$$It is recommended to use the whitelist to prevent false positives in spam detection$$">$$DISABLED!$$</font>', 					
			'part':'<font color="red" title="$$It is recommended to use the whitelist to prevent false positives in spam detection$$">$$PARTLY DISABLED!$$</font>',
			'enabled':'<font color="green">$$ENABLED$$</font>'
		}
		usercgi_status['spam']={
			'disabled':'<font style="color:#888">$$INACTIVE$$</font>',
			'markonly':'<font color="green">$$MARK ONLY$$</font>',
			'enabled':'<font color="green">$$ENABLED$$</font>',
			'kidsafe':'<font color="green">$$KIDSAFE$$</font>',
			'custom':'<font color="green">$$ENABLED$$</font>',
			'warn':'<font color="red" title="$$Other settings recommended now for better spam prevention$$">$$CUSTOM!$$</font>'
		};
		usercgi_status['unknown']={
			'disabled':'<font style="color:#888">$$INACTIVE$$</font>',
			'mark':'<font color="green">$$MARK ONLY$$</font>',
			'enabled':'<font color="green">$$ENABLED$$</font>',
			'kidsafe':'<font color="green">$$KIDSAFE$$</font>'
		}
				usercgi_status['extras']={
			'legal':'||request_user_can_use_legal_archive||',
			'notify':'||request_enotify||',
			'lists':'||request_lists||',
			'import':'||request_mailbox||',
			'alias':'||request_alias||',
			'cleanup':'||request_cleanup||',
# 			list_quota and alias_quota are callbacks so cannot combine in template variable expression, using javascript instead
			'lists_quota':'||list_quota||',
			'alias_quota':'||alias_quota||'
		};