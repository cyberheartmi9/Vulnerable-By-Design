var crumb_urls={'Home':'index.htm',
				'Products':'products.htm',
				'Support':'support.htm',
				'Documentation':'documentation.htm',
				'Surgemail':'surgemail/',
				'SurgeWeb Manual':'surgeweb/help/index.htm',
				"YesI'mOnline Manual":'yes/help/index.htm',
				'Local Surgemail':'',
				'SurgeMail Help Index':'surgemail/help/index.htm'	// Note defined lower down the page too
				};


function display_crumbs(o,level)
{
    document.open();
    document.writeln('<p class="s_crumb">');
    var len=o.length;
	for(var i=0;i<len;i++){
		var url='';
		var do_url=(o[i] && o[i]!='...');
		if(do_url){
			if(level) for (var j=1;j<level;j++){
				url+='../';
			}
			url+=crumb_urls[o[i]];
		}
		if(do_url && i+1<len){ 
			document.writeln('<a href="'+url+'" class="sLocator">'+o[i]+'</a> ');
		}else{ 
			document.writeln(o[i]);
	    }
	    if(i+1<len) document.writeln(' &gt; ');
	}
    document.writeln('</p>');
}

function display_crumbs_doc(o,level)
{
	offline_check();
	if(offline_manual){
		crumb_urls['SurgeMail Help Index']='help/index.htm';

		if(o[3])
			display_crumbs(['Local Surgemail',o[2],o[3]],2);
		else
			display_crumbs(['Local Surgemail',o[2]],2);
	}else{
		display_crumbs(o,level);
	}
}

function search_details(description,url)
{
	return;
	dge('search_description').innerHTML=description;
	dge('search_sitesearch').value=url;
	dge('search_domains').value=url;
}

function index_select(id)
{
	var el=dge(id);
	if(!el) return;
	class_add(el,'selected');
	if(el.childNodes.length>1 && el.childNodes[1].childNodes.length>1) 
		class_add(el,'sub');			
	el.style.display='block';
	var pp=el.parentNode.parentNode;
	if(class_contains(pp,'group_hidden')){
		class_remove(pp,'group_hidden');
		class_add(el.parentNode,'group_open');
	}
}
// ****

function menu_handler(e)
{
	var t=target(e);
	var mnu=ancestor_by_class(t,'menu');
	var btn=ancestor_by_class(t,'top_item');
	if(mnu.active) class_remove(mnu.active,'selected');
	class_add(btn,'selected');
	if(mnu.active){
		var mid=mnu.active.getAttribute('mid');
		if(mid)menu_hide(mid);
	}
	mnu.active=btn;
	if (!btn) return;
	var mid=btn.getAttribute('mid');
	if(!mid) return;
	var el=dge('width_limit_div');
	do_menu_show(mid,e,undefined,undefined,{xoffset:-el.offsetLeft,yoffset:el.offsetTop});
}




// Utility functions


var CLASSNAME = "className";

function class_remove(o,name){
	if (!o) return;
	if(o[CLASSNAME]==undefined)
		debugger;
	
	o[CLASSNAME] = o[CLASSNAME].replace(' '+name,'').replace(name,'');
}
function class_add(o,name){
	if (!o) return;
    var val = o[CLASSNAME];
	if (val.indexOf(name) == -1) 
		o[CLASSNAME] += (val?' ':'')+name;
}
function class_contains(o,name){
	if (!o) return;
    return (o[CLASSNAME].indexOf(name) != -1);
}
function class_set(o,name){
    o[CLASSNAME]=name;
}

function ancestor_by_att(o, txt)
{
    while (o && o.getAttribute && !o.getAttribute(txt)) o = o.parentNode;
    return o && o.getAttribute ? o : null;
};
function ancestor_by_class(o, txt)
{
    while (o && (o.className!=undefined || o.className) && !class_contains(o,txt)) o = o.parentNode;
    return o && o.className? o : null;
};
function ancestor_by_tag(o, txt)
{
    while (o && o.tagName.toLowerCase()!=txt) o = o.parentNode;
    return o;
};

function target(e){
	var src;
	if(e.target){
		src = e.target;
	}else if(e.srcElement){
		src = e.srcElement;
	}
	if (src.nodeType==3) src = src.parentNode;
	return src;
}

function dge(a) { return document.getElementById(a); }

function shadofy(o,prefix)
{
	var el;
	if(o.shadofied) return;
	if(!prefix) prefix='';
	var shadows=['top_left','top_edge','top_right','left_edge','right_edge','bottom_left','bottom_edge','bottom_right'];
	for(var i=0;i<shadows.length;i++){
		el=new_element(o,'div');
		class_add(el,prefix+shadows[i]);
		class_add(el,'shadow');
		el.onclick=function(){dbg("SHADOW onclick")};
	}
	o.shadofied=true;
}

function menu_position(ctl,mnu,opt,ctl2)
{
	var pos = posn_offset(ctl);
	if(ctl2) pos = posn_offset(ctl2,pos);

	if(!opt) opt={};
	if(opt.xoffset) pos[0]+=opt.xoffset;
	if(opt.right) pos[0]+=ctl.offsetWidth-mnu.offsetWidth;

	if(opt.yoffset) pos[1]-=opt.yoffset;
	if(opt.upwards)
		pos[1]-=mnu.offsetHeight;
	else
		pos[1]+=ctl.offsetHeight-2;	
	position_node(mnu,pos);
}
function menu_position_cursor(e,mnu,opt)
{
	var pos = [mouseX(e),mouseY(e)]
	position_node(mnu,pos);
}
function posn_offset(ctl,pos)
{
	if (!pos) pos=[0,0];
	for(var p=ctl;p.offsetParent;p=p.offsetParent) pos[0]+=p.offsetLeft;
	for(var p=ctl;p.offsetParent;p=p.offsetParent) pos[1]+=p.offsetTop;
	return pos;
}
function position_node(mnu,pos)
{
	mnu.style.left=px(pos[0]);
	mnu.style.top=px(pos[1]);
}
function px(value){
	if (value<=0) return "1px";
	return value+"px";
}
function new_element(b,c){
    var d=document.createElement(c);
    b.appendChild(d);
    return d
}


var global_active_menu,menu_timer,allow_move_hide;
function do_menu_show(id,e,own_calc,fn,posn)
{
	mnu=dge(id);
	if(fn) mnu.cb=fn;
	var t;	
	if(e) {
		t=target(e);
		if (t.tagName.toLowerCase()=='img') 
			t=t.parentNode;
		var tt=ancestor_by_class(t,'top_item');
		if(tt) t=tt;
	}
	if(posn && posn['t'])
		t=posn.t;
	if (menu_timer)	clearTimeout(menu_timer);
	if(posn && posn['cursor'])
		menu_position_cursor(e,mnu,posn);
	else
		menu_position(t,mnu,posn);

//	Ajax only interface functionality
	shadofy(mnu,'mnu_');
	class_remove(mnu,'hidden');
	class_add(tt,'selected');
	global_active_menu=mnu;
	allow_move_hide=true;
}

document.onclick=function(e){
	if (global_active_menu){
		menu_hide2(global_active_menu);
	}
}
document.onmousemove=function(e){
	if (global_active_menu && allow_move_hide){
		x_hide_menu_soon(global_active_menu.id);
		allow_move_hide=false;
	}
}
function menu_hide2(mnu)
{
	class_add(mnu,'hidden');
	global_active_menu=null;
	
	var mnu=dge('page_menu');
	if(mnu.active) {
		class_remove(mnu.active,'selected');	
	}
}

function menu_action_mouseout(e,txt){
	if (!e) e = window.event;
	var t = target(e);
	if (class_contains(t,'shadow')){
		var el=ancestor_by_class(t,'xmenu');
		if(el.fresh) {
			return;
		}
	}
	x_hide_menu_soon(txt);
}
function menu_action_mouseover(e,txt){
	if (!e) e = window.event;
	var t = target(e);
	if(!class_contains(t,'shadow')){
		var el=ancestor_by_class(t,'xmenu');
		if(el) el.fresh=false;
	}
	if (menu_timer)	clearTimeout(menu_timer);
}
function x_hide_menu_soon(txt)
{
	if (menu_timer)	clearTimeout(menu_timer);
	menu_timer=setTimeout(function(){
		menu_hide(txt);
	}
	,200);
}
function menu_mouseup(id)
{
	var o=dge(id);
	if(!o) return;
	if(o.fresh) {
//		stopEvent(e);
		return;
	}
	menu_hide(id);
}
function menu_hide_ex(e,id,param)
{
	t=target(e);
	if(class_contains(t,'shadow')) {
//		Hack for IE not catching events properly	
//		if (isIE) ignore_one_hide=true;	
		return;
	}
	return menu_hide(id,param);
}
function menu_hide(id,param)
{
	var o=dge(id);
	if(!o) return;
	class_add(o,'hidden');
	global_active_menu=null;
	if (o.cb)
		o.cb('hide',param);
	var mnu=dge('page_menu');
	if(mnu.active) {
		class_remove(mnu.active,'selected');	
	}
}

function x()
{
	document.href='/surgewb?show=site/test.htm';
}

function switch_look(id,url)
{
  var el=document.getElementById(id);
  el.parentNode.removeChild(el);

  var html_doc = document.getElementsByTagName('head').item(0);
  el = document.createElement('link');
  el.setAttribute('rel','stylesheet');
  el.setAttribute('type','text/css');
  el.setAttribute('href',url);
  el.id=id;
  html_doc.appendChild(el);
}

var offline_manual=false;
function offline_check()
{
	var el=dge('main_logo');
	if(el && el.src && el.src.indexOf('template'))
		offline_manual=true;
}

// Images downloaded for all pages
var prefetch_img_urls=[	'shadow_cnr.png','shadow_cnr.png','shadow_vert.png','shadow_horiz.png',
						'menu2_btn_l.png','menu2_btn_c.png','menu2_btn_r.png'];

// Images only downloaded for netwinsite.com pages (not for offline surgemail manual etc)
var prefetch_img_extra=[ 'download_hover.png','readmore_hover.png'];

var prefetch_img_images=[];

function prefetch_images()
{
	var root='/img2/';
	var local_manual=false;
	if(offline_manual){
		root='template/img2/';
	}else{
		prefetch_img_urls.push(prefetch_img_extra);
	}
	for(var i=0;i<prefetch_img_urls.length;i++){
		prefetch_img_images.push(new Image());
		prefetch_img_images[i].src=root+prefetch_img_urls[i];
	}	
}
window.onload=init_page;
function init_page()
{	
	offline_check();
	prefetch_images();
	if(window.do_scroll_menu){
		scroll_menu();
		document.body.onscroll=scroll_menu;
		window.onscroll=scroll_menu;
	}
}


var scrollsoon_timer;
function scroll_menu()
{
	if(scrollsoon_timer) clearTimeout(scrollsoon_timer);	
	scrollsoon_timer=setTimeout(scroll_menu_timed,150);
}
function scroll_menu_timed()
{
	var top;	
	if (self.pageYOffset){
		top = self.pageYOffset;
	}else if (document.documentElement && document.documentElement.scrollTop) { 
		top = document.documentElement.scrollTop; 
	}else if (document.body) { 
		top = document.body.scrollTop; 
	}
	top-=110;
	if (top<30) top=30;

	dbg(top);
	document.getElementById('floating_index').style.top = top+'px';
}


var comments, current_comment=0;

function next_comment(e,delta)
{
	if(!comments){
		comments=[
		
			'Wow! surgemail ROCKS!!! :) I have setup surgemail as a bastion host for 5 of our primary domains. We tried every other mail server out there trying to find something that works and that could keep up with our mail throughput.'+
			'<br><br>'+
			'I\'m BLOWN AWAY by just how good Surgemail is!'+
			'It is processing hundreds of thousands of messages per day and scanning every one for viruses with RAV and giving each one a SmiteCRC spamdetect score. The dual PIII 1Ghz server is only using 1-5% CPU with spikes to 20-30% and only 150MB out of 2GB!!! Amazing.'+
			'<br><br>'+
			'If you are looking for a reliable and FAST mail server, BUY SURGEMAIL!'+
			'<br><br>'+
			'<b>-- Robert Boyle - Tellurian Networks - The Ultimate Internet Connection</b>',

			'ALL the programmers, support people, accounting people, well the entire company is OUTSTANDING '+
			'- If you are or were a US Marine you will know what that means !'+
			'<br><br>'+
			'I have NEVER had the responsiveness that Net Win provides!'+
			'The technical support is the best I have ever worked with. They do NOT give up, '+
			'they help you all the way ! Even before the purchase !'+
			'<br><br>'+
			' From this stand point alone, '+
			'everyone who operates an ISP and provides custom FTP, EMAIL, and CHAT services NEEDS these products !'+
			'<br><br>'+
			'<b>-- Jon Unglert - CEO - Ix Technologies, Inc &amp; ISGroup, Inc.</b>',

			'As a provider with hundreds of mail domains, we have had an ongoing battle with spam in all its forms. NetWin have always been there to listen to our needs and has often added features to SurgeMail to help us streamline our mail services. We have had a tough time finding a mail server that meets all our needs in an easy to install, and even easier to manage system. '+
			'<br><br>'+
			'Its anti-spam features are some of the most advanced I have ever had the pleasure of working with, while the user configurable "Friends" system puts spam protection firmly in the hands of the users. If you are looking for a true carrier class mail system which will handle anything you throw at it, and beg for more, look no further than SurgeMail. '+
			'<br><br>'+
			'There are too many features to mention, just download the demo and take a look, you will be more than pleasantly surprised.'+
			'<br><br>'+
			'<b>-- Michael Dunne - CairnsNet</b>',

			'NetWinSite DBabble software is superb-- exactly what we need at Sun and Netscape.'+
			'It is perfect for corporate discussion groups and messaging.'+
			'<br><br>'+
			'<b>-- Joel Parker Henderson - Sun Microsystems</b>',

			'<br><br>'+
			'You can find more comments from surgemail users <a href="/surgemail/customers.htm">here</a>.'+
			'<br><br>'
		];
	}

	current_comment+=delta;
	if(current_comment<0) 
		current_comment=comments.length-1;
	if(current_comment>comments.length-1) 
		current_comment=0;
	dge('comment1').innerHTML=comments[current_comment];
	stopEvent(e);
}

function stopEvent(e) {
	if(!e) return;

	//e.cancelBubble is supported by IE - this will kill the bubbling process.
	e.cancelBubble = true;
	e.returnValue = false;

	//e.stopPropagation works only in Firefox.
	if (e.stopPropagation) {
		e.stopPropagation();
		e.preventDefault();
	}
}
function stopBubble(e) {
	if(!e) var e = window.event;
	e.cancelBubble = true;
	if (e.stopPropagation) {
		e.stopPropagation();
	}
}

function dbg(){}	// dummy function if debug library is not included

function index_toggle(e)
{
	var el=target(e);
	var p=el.parentNode;
	if(class_contains(p,'group_hidden')){
		class_remove(p,'group_hidden')
		class_add(el,'group_open')		
	}else{
		class_add(p,'group_hidden')
		class_remove(el,'group_open')		
	}
}

function touch_menu_toggle()
{
	var menu=dge('touch_menu_items');
	var img=dge('touch_menu_image');
	if(class_contains(menu,'hidden')){
		class_remove(menu, 'hidden');
		img.src='/img2/close.png';
	}else{
		class_add(menu, 'hidden');
		img.src='/img2/burger.png';
	}
}
